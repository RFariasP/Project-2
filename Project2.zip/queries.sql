CREATE TABLE parks (
id TEXT PRIMARY KEY,
park_name TEXT,
us_state TEXT,
acres TEXT,
latitude DECIMAL,
longitude DECIMAL
);

CREATE TABLE species (
id TEXT PRIMARY KEY,
species_id TEXT,
park_name TEXT,
sc_name TEXT,
common_name TEXT,
record_status TEXT,
nativeness TEXT,
id_category TEXT,
id_order TEXT,
id_family text
);


CREATE TABLE category_sp (
id TEXT PRIMARY KEY,
category_sp TEXT
);

CREATE TABLE order_sp (
id TEXT PRIMARY KEY,
order_sp TEXT
);

CREATE TABLE family_sp (
id TEXT PRIMARY KEY,
family_sp TEXT
);